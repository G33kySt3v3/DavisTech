﻿using CityInfo.API.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CityInfo.API
{
    public static class CityInfoContextExtensions
    {
        public static void EnsureSeedDataForContext(this CityInfoContext context)
        {
            if (context.Cities.Any())
            {
                return;
            }

            //init seed data
            var cities = new List<City>()
            {
                new City()
                {
                    Name = "New York City",
                    Description = "The one with that big park.",
                    PointsOfInterest = new List<PointOfInterest>()
                    {
                        new PointOfInterest() {
                            Name = "Central Park",
                            Description = "The most visited urban park in the United States"
                        },
                        new PointOfInterest() {
                            Name = "Empire State Building",
                            Description = "a 102-story skyscraper located in Midtown Manhattan."
                        },
                    }
                },
                new City()
                {
                    Name = "Copenhagen",
                    Description = "The one with the colorful buildins on the canals.",
                    PointsOfInterest = new List<PointOfInterest>()
                    {
                        new PointOfInterest() {
                            Name = "Cathedral of Our Lady",
                            Description = "A Gothic style cathedral, conceived by architects Jan and Pieter Appelmans."
                        },
                        new PointOfInterest() {
                            Name = "Antwerp Central Station",
                            Description = "The finest example of railway architecture in Belgium."
                        },
                    }
                },
                new City()
                {
                    Name = "Paris",
                    Description = "The one with that big tower.",
                    PointsOfInterest = new List<PointOfInterest>()
                    {
                        new PointOfInterest() {
                            Name = "Eiffel Tower",
                            Description = "A wrought iron lattice tower on the Champ de Mars, name after engineer Gustave Eiffel."
                        },
                        new PointOfInterest() {
                            Name = "The Lourve",
                            Description = "The world's largest musuem."
                        },
                    }
                },
                new City()
                {
                    Name = "Salt Lake City",
                    Description = "The one with a huge temple.",
                    PointsOfInterest = new List<PointOfInterest>()
                    {
                        new PointOfInterest() {
                            Name = "Temple Square",
                            Description = "A 10-acre complex in the center of Salt Lake City including several church facilities."
                        },
                        new PointOfInterest() {
                            Name = "Hogle Zoo",
                            Description = "A 42-acre zoo that houses animals from many diverse ecosystems."
                        },
                    }
                },
                new City()
                {
                    Name = "Las Vegas",
                    Description = "The one with hotels and casinos everywhere.",
                    PointsOfInterest = new List<PointOfInterest>()
                    {
                        new PointOfInterest() {
                            Name = "The Stratosphere",
                            Description = "A giant hotel/casino on the Las Vegas Strip 1,149 ft. tall with three amusement rides on top."
                        },
                    }
                },
                new City()
                {
                    Name = "San Fransisco",
                    Description = "The one with the giant bridge.",
                    PointsOfInterest = new List<PointOfInterest>()
                    {
                        new PointOfInterest()
                        {
                            Name = "Golden Gate Bridge",
                            Description = "A large supsension bridge spanning over the mile wide Golden Gate Strait."
                        },
                    }
                }
            };

            context.Cities.AddRange(cities);
            context.SaveChanges();

        }
    }
}
