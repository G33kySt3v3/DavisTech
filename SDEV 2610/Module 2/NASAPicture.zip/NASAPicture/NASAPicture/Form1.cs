﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using Newtonsoft.Json;

namespace NASAPicture
{
    public partial class formNASA : Form
    {
        public formNASA()
        {
            InitializeComponent();
        }

        private async void btnGo_Click(object sender, EventArgs e)
        {
            //create a new HTTP client object
            HttpClient client = new HttpClient();
            txtJSON.Clear();
            //create variables
            string baseurl = "https://api.nasa.gov/planetary/apod?";
            string apikey = "api_key=4Saz9meeJQi1RgeyLctPuykYpkT5XL7ebZI3CDBS";
            string date = "&date=" + datePick.Text;

            try
            {
                //make HTTP call
                HttpResponseMessage response = await client.GetAsync(baseurl + apikey + date);
                response.EnsureSuccessStatusCode(); //this will throw exception if not successful
                var responseBody = await response.Content.ReadAsStringAsync();
                //deserialize JSON object
                dynamic stuff = JsonConvert.DeserializeObject<dynamic>(responseBody);
                //now display parts of JSON content
                txtJSON.Text = response.Headers.ToString() + stuff.ToString();
                lblTitle.Text = stuff.title;
                lblDesc.Text = stuff.explanation;
                picAPOD.ImageLocation = stuff.url;
            }
            catch (HttpRequestException exc)
            {
                txtJSON.Text = "Exception: " + exc.Message;
            }
        }
    }
}
