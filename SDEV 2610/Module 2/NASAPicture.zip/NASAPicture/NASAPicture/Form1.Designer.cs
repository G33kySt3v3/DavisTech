﻿namespace NASAPicture
{
    partial class formNASA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFormName = new System.Windows.Forms.Label();
            this.lblDaySelect = new System.Windows.Forms.Label();
            this.datePick = new System.Windows.Forms.DateTimePicker();
            this.btnGo = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblJSON = new System.Windows.Forms.Label();
            this.picAPOD = new System.Windows.Forms.PictureBox();
            this.txtJSON = new System.Windows.Forms.RichTextBox();
            this.lblDesc = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picAPOD)).BeginInit();
            this.SuspendLayout();
            // 
            // lblFormName
            // 
            this.lblFormName.AutoSize = true;
            this.lblFormName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lblFormName.Location = new System.Drawing.Point(26, 29);
            this.lblFormName.Name = "lblFormName";
            this.lblFormName.Size = new System.Drawing.Size(308, 24);
            this.lblFormName.TabIndex = 0;
            this.lblFormName.Text = "NASA Astronomy Picture of the Day";
            // 
            // lblDaySelect
            // 
            this.lblDaySelect.AutoSize = true;
            this.lblDaySelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblDaySelect.Location = new System.Drawing.Point(395, 42);
            this.lblDaySelect.Name = "lblDaySelect";
            this.lblDaySelect.Size = new System.Drawing.Size(117, 20);
            this.lblDaySelect.TabIndex = 1;
            this.lblDaySelect.Text = "Select the Day:";
            // 
            // datePick
            // 
            this.datePick.CustomFormat = "yyyy-MM-dd";
            this.datePick.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.datePick.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datePick.Location = new System.Drawing.Point(518, 37);
            this.datePick.Name = "datePick";
            this.datePick.Size = new System.Drawing.Size(139, 26);
            this.datePick.TabIndex = 2;
            this.datePick.Value = new System.DateTime(2019, 9, 11, 0, 0, 0, 0);
            // 
            // btnGo
            // 
            this.btnGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnGo.Location = new System.Drawing.Point(694, 29);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(90, 46);
            this.btnGo.TabIndex = 3;
            this.btnGo.Text = "GO";
            this.btnGo.UseVisualStyleBackColor = true;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblTitle.Location = new System.Drawing.Point(26, 95);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(38, 20);
            this.lblTitle.TabIndex = 4;
            this.lblTitle.Text = "Title";
            // 
            // lblJSON
            // 
            this.lblJSON.AutoSize = true;
            this.lblJSON.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblJSON.Location = new System.Drawing.Point(911, 37);
            this.lblJSON.Name = "lblJSON";
            this.lblJSON.Size = new System.Drawing.Size(51, 20);
            this.lblJSON.TabIndex = 5;
            this.lblJSON.Text = "JSON";
            // 
            // picAPOD
            // 
            this.picAPOD.Location = new System.Drawing.Point(30, 118);
            this.picAPOD.Name = "picAPOD";
            this.picAPOD.Size = new System.Drawing.Size(865, 637);
            this.picAPOD.TabIndex = 6;
            this.picAPOD.TabStop = false;
            // 
            // txtJSON
            // 
            this.txtJSON.Location = new System.Drawing.Point(915, 60);
            this.txtJSON.Name = "txtJSON";
            this.txtJSON.Size = new System.Drawing.Size(292, 883);
            this.txtJSON.TabIndex = 7;
            this.txtJSON.Text = "";
            // 
            // lblDesc
            // 
            this.lblDesc.AutoSize = true;
            this.lblDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblDesc.Location = new System.Drawing.Point(27, 758);
            this.lblDesc.MaximumSize = new System.Drawing.Size(800, 0);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(79, 17);
            this.lblDesc.TabIndex = 8;
            this.lblDesc.Text = "Description";
            // 
            // formNASA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1219, 955);
            this.Controls.Add(this.lblDesc);
            this.Controls.Add(this.txtJSON);
            this.Controls.Add(this.picAPOD);
            this.Controls.Add(this.lblJSON);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnGo);
            this.Controls.Add(this.datePick);
            this.Controls.Add(this.lblDaySelect);
            this.Controls.Add(this.lblFormName);
            this.Name = "formNASA";
            this.Text = "NASA Picture of the Day";
            ((System.ComponentModel.ISupportInitialize)(this.picAPOD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFormName;
        private System.Windows.Forms.Label lblDaySelect;
        private System.Windows.Forms.DateTimePicker datePick;
        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblJSON;
        private System.Windows.Forms.PictureBox picAPOD;
        private System.Windows.Forms.RichTextBox txtJSON;
        private System.Windows.Forms.Label lblDesc;
    }
}

